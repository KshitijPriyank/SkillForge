package com.example.study_planner_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
