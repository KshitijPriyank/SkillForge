import 'package:flutter/material.dart';

class TimetableScreen extends StatelessWidget {
  final String courseName;
  final String courseCode;

  const TimetableScreen({
    Key? key,
    required this.courseName,
    required this.courseCode,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Timetable"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Course Name:',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              courseName,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Course Code:',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              courseCode,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
