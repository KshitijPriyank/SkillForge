import 'package:flutter/material.dart';
import 'package:study_planner_app/student_info.dart';
import 'package:study_planner_app/timetable_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Study Planner',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: StudentInfoScreen(),
    );
  }
}
