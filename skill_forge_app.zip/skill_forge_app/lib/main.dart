import 'package:flutter/material.dart';
import 'package:skill_forge_app/screens/student_info.dart';
import 'package:skill_forge_app/forge/screens/timetable_screen.dart';

void main() => runApp(SkillForge());

class SkillForge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SkillForge',
      initialRoute: '/',
      routes: {
        '/': (context) => SplashPage(),
        '/studentinfo': (context) => StudentInfo(),
        '/timetable': (context) => TimetableScreen(),
      },
      theme: ThemeData.dark(),
    );
  }
}

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _animation;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _animation = Tween<double>(begin: 0, end: 1).animate(_controller!)
      ..addListener(() {
        setState(() {});
      });
    _controller!.forward();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.grey[900],
        child: Center(
          child: Opacity(
            opacity: _animation!.value,
            child: Text(
              'SkillForge',
              style: TextStyle(
                color: Colors.white,
                fontSize: 32.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
