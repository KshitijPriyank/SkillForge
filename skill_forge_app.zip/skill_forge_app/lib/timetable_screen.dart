import 'package:flutter/material.dart';
import 'package:skillforge_flutter_app/models/subject.dart';
import 'package:skillforge_flutter_app/models/timetable.dart';

class TimetableScreen extends StatelessWidget {
  final String name;
  final DateTime examDate;
  final List<Subject> selectedSubjects;
  final List<String> selectedChapters;
  final Map<String, int> difficultyLevels;

  TimetableScreen({
    required this.name,
    required this.examDate,
    required this.selectedSubjects,
    required this.selectedChapters,
    required this.difficultyLevels,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SkillForge'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Hello $name!',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20.0),
            Text(
              'Here is your exam timetable:',
              style: TextStyle(
                fontSize: 18.0,
              ),
            ),
            SizedBox(height: 20.0),
            Table(
              border: TableBorder.all(),
              columnWidths: {
                0: FlexColumnWidth(3),
                1: FlexColumnWidth(1),
                2: FlexColumnWidth(1),
                3: FlexColumnWidth(1),
                4: FlexColumnWidth(1),
                5: FlexColumnWidth(1),
                6: FlexColumnWidth(1),
              },
              children: [
                TableRow(
                  children: [
                    TableCell(
                      child: Center(child: Text('Subjects')),
                    ),
                    TableCell(
                      child: Center(child: Text('Chapter 1')),
                    ),
                    TableCell(
                      child: Center(child: Text('Chapter 2')),
                    ),
                    TableCell(
                      child: Center(child: Text('Chapter 3')),
                    ),
                    TableCell(
                      child: Center(child: Text('Chapter 4')),
                    ),
                    TableCell(
                      child: Center(child: Text('Chapter 5')),
                    ),
                    TableCell(
                      child: Center(child: Text('Difficulty')),
                    ),
                  ],
                ),
                ...selectedSubjects.map((subject) {
                  return TableRow(
                    children: [
                      TableCell(
                        child: Text(subject.name),
                      ),
                      ...List.generate(
                        5,
                            (index) {
                          final chapter = '${subject.name} Ch.${index + 1}';
                          return TableCell(
                            child: Center(
                              child: selectedChapters.contains(chapter)
                                  ? Icon(
                                Icons.check_circle,
                                color: Colors.green,
                              )
                                  : Icon(
                                Icons.remove_circle_outline,
                                color: Colors.red,
                              ),
                            ),
                          );
                        },
                      ),
                      TableCell(
                        child: Center(
                          child: Text(
                            '${difficultyLevels[subject.name]}/10',
                            style: TextStyle(
                              color: difficultyLevels[subject.name]! < 6
                                  ? Colors.red
                                  : Colors.green,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }),
              ],
            ),
            SizedBox(height: 20.0),
            Text(
              'Exam date: ${examDate.toString()}',
              style: TextStyle(
                fontSize: 18.0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
