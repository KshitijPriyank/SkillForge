package com.example.skill_forge_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
